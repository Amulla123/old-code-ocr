document.addEventListener('DOMContentLoaded', () => {
    const scanPageButton = document.getElementById('scanPageButton');
    const statusDiv = document.getElementById('status');
    const resultsDiv = document.getElementById('results');

    // Function to update the status
    function updateStatus(message) {
        statusDiv.textContent = message;
    }

    // Function to display results
    function displayResults(results) {
        resultsDiv.textContent = JSON.stringify(results, null, 2);
    }

    // Event listener for the scan button
    scanPageButton.addEventListener('click', () => {
        updateStatus('Scanning page...');
        chrome.tabs.query({active: true, currentWindow: true}, tabs => {
            // Send a message to the content script
            chrome.tabs.sendMessage(tabs[0].id, {action: 'performOCR'}, response => {
                if (response.error) {
                    updateStatus('Error occurred.');
                    console.error('Error:', response.error);
                } else {
                    updateStatus('Scan complete.');
                    displayResults(response);
                }
            });
        });
    });
});
