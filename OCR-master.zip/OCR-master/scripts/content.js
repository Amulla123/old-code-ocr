// Function to convert image to Base64
function getImageBase64(img, callback) {
  const reader = new FileReader();
  reader.onloadend = function() {
      callback(reader.result.split(',')[1]); // Removes the Base64 prefix ("data:image/png;base64,")
  };
  reader.readAsDataURL(img);
}

// Function to capture images on the page
function captureImages() {
  const images = document.querySelectorAll('img');
  images.forEach(img => {
      // Only consider images larger than certain dimensions to avoid icons
      if (img.naturalWidth > 100 && img.naturalHeight > 100) {
          // Create an off-screen canvas
          const canvas = document.createElement('canvas');
          canvas.width = img.naturalWidth;
          canvas.height = img.naturalHeight;

          // Copy the image contents to the canvas
          const ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0);

          // Convert the canvas to a data URL in PNG format
          canvas.toBlob(blob => {
              getImageBase64(blob, base64 => {
                  // Send the image data to the background script
                  chrome.runtime.sendMessage({ action: 'performOCR', imageData: base64 }, response => {
                      if (response.error) {
                          console.error('Error:', response.error);
                      } else {
                          // Handle the response here
                          console.log('OCR Response:', response);
                      }
                  });
              });
          }, 'image/png');
      }
  });
}

// Listen for a specific event from the popup or background script
// Example: A command to start capturing and analyzing images
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.command === 'startCapture') {
      captureImages();
      sendResponse({status: 'Image processing started'});
  }
});

// Optionally, automatically start capturing images when the page loads
// captureImages();
