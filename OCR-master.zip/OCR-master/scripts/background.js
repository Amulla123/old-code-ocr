// Function to get the OAuth token
function getOAuthToken(callback) {
  chrome.identity.getAuthToken({ interactive: true }, function(token) {
      if (chrome.runtime.lastError) {
          console.error(chrome.runtime.lastError);
          callback(null);
      } else {
          callback(token);
      }
  });
}

// Function to call the Google Cloud Vision API
function callVisionAPI(token, imageData, callback) {
  const visionApiUrl = 'https://vision.googleapis.com/v1/images:annotate';

  fetch(visionApiUrl, {
      method: 'POST',
      headers: {
          'Authorization': 'Bearer ' + token,
          'Content-Type': 'application/json'
      },
      body: JSON.stringify({
          requests: [{
              image: { content: imageData },
              features: [{ type: 'TEXT_DETECTION' }]
          }]
      })
  })
  .then(response => response.json())
  .then(response => {
      callback(response);
  })
  .catch(error => {
      console.error('Vision API Error:', error);
      callback(null);
  });
}

// Listen for messages from content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'performOCR') {
      getOAuthToken(token => {
          if (token) {
              callVisionAPI(token, request.imageData, response => {
                  if (response) {
                      // Process the Cloud Vision API response
                      // Example: sendResponse({ text: response.responses[0].fullTextAnnotation.text });
                      sendResponse(response);
                  } else {
                      sendResponse({ error: 'Error processing image.' });
                  }
              });
          } else {
              sendResponse({ error: 'Unable to get OAuth token.' });
          }
      });

      return true; // Indicates you wish to send a response asynchronously
  }
});

// Handle installed or updated events for the extension
chrome.runtime.onInstalled.addListener(() => {
  console.log('Phishing Detection Extension installed.');
  // Perform any setup or migrations necessary
});
